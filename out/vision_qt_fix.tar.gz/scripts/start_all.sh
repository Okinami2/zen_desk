#!/bin/sh
# 慧学引擎 - 一键启动所有服务
# 启动顺序: fusion(必须先起, 监听8888) → radar/asr(连fusion) → vision(独立)

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJ_DIR="$(dirname "$SCRIPT_DIR")"
. "$SCRIPT_DIR/env.sh"
BIN_DIR="$PROJ_DIR/out/bin"
LOG_DIR="$PROJ_DIR/out/log"
PID_DIR="$PROJ_DIR/out/pid"
VISION_ENABLE="${VISION_ENABLE:-1}"

mkdir -p "$LOG_DIR" "$PID_DIR"

# 检查是否已启动，清理僵尸 PID 文件
if [ -f "$PID_DIR/fusion_service.pid" ]; then
    old_pid=$(cat "$PID_DIR/fusion_service.pid")
    if kill -0 "$old_pid" 2>/dev/null; then
        echo "[WARN] fusion_service already running? pid=$old_pid"
        echo "       If you want to restart, run stop_all.sh first."
        exit 1
    else
        echo "[INFO] Found stale fusion_service.pid, cleaning up..."
        rm -f "$PID_DIR/"*.pid
    fi
fi

echo "===== 慧学引擎 - 启动所有服务 ====="

echo "[0/2] Applying board pin mapping..."
if ! "$BIN_DIR/pinmux_init" --apply >"$LOG_DIR/pinmux_init.log" 2>&1; then
    echo "       pinmux_init failed; see $LOG_DIR/pinmux_init.log" >&2
    cat "$LOG_DIR/pinmux_init.log" >&2
    exit 1
fi

# ---- 1. fusion_service (必须先启动, 监听 TCP 8888) ----
echo "[1/2] Starting fusion_service..."
"$BIN_DIR/fusion_service" \
    >"$LOG_DIR/fusion_service.log" 2>&1 &
echo $! > "$PID_DIR/fusion_service.pid"
sleep 1
echo "       fusion_service started (pid=$(cat $PID_DIR/fusion_service.pid))"

# ---- 2. radar_service (连接 fusion) ----
echo "[2/2] Starting radar_service..."
"$BIN_DIR/radar_service" \
    >"$LOG_DIR/radar_service.log" 2>&1 &
echo $! > "$PID_DIR/radar_service.pid"
sleep 1
echo "       radar_service started (pid=$(cat $PID_DIR/radar_service.pid))"

# ---- 3. asr_service (连接 fusion) ----
echo "[3/4] Starting asr_service..."
"$BIN_DIR/asr_service" \
    >"$LOG_DIR/asr_service.log" 2>&1 &
echo $! > "$PID_DIR/asr_service.pid"
sleep 1
echo "       asr_service started (pid=$(cat $PID_DIR/asr_service.pid))"

# ---- 4. device_service (EC11旋钮等) ----
echo "[4/4] Skipping standalone device_service (now embedded in fusion_service)..."

# ---- 5. vision_service (独立 UVC + NPU, 输出 telemetry/snapshots) ----
if [ "$VISION_ENABLE" = "1" ]; then
    echo "[5/5] Starting vision_service..."
    "$SCRIPT_DIR/start_vision.sh"
else
    echo "[5/5] Skipping vision_service (VISION_ENABLE=$VISION_ENABLE)"
fi

echo ""
echo "===== All services started ====="
echo "  fusion:  pid=$(cat $PID_DIR/fusion_service.pid)  log=$LOG_DIR/fusion_service.log"
echo "  radar:   pid=$(cat $PID_DIR/radar_service.pid)   log=$LOG_DIR/radar_service.log"
echo "  asr:     pid=$(cat $PID_DIR/asr_service.pid)     log=$LOG_DIR/asr_service.log"
if [ -f "$PID_DIR/vision_service.pid" ]; then
echo "  vision:  pid=$(cat $PID_DIR/vision_service.pid)  log=$LOG_DIR/vision_service.log"
fi
echo ""
echo "  Run 'tail -f $LOG_DIR/fusion_service.log' to watch fusion"
echo "  Run 'tail -f $LOG_DIR/radar_service.log'  to watch radar"
echo "  Run 'tail -f $LOG_DIR/asr_service.log'    to watch asr"
echo "  Run 'tail -f $LOG_DIR/vision_service.log' to watch vision"
echo "  Run 'scripts/stop_all.sh' to stop all services"
